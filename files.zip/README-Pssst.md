# Pssst — application Android (APK)

Pssst détecte les téléphones proches qui ont l'application, permet d'envoyer une demande « pssst »,
et une fois la demande acceptée, d'échanger numéro de téléphone et réseaux sociaux.
On peut ensuite s'écrire en direct et créer des groupes, **sans Internet**
(Bluetooth + Wi-Fi direct via Google Nearby Connections).

## 1. Obtenir l'APK sans rien installer (recommandé) — avec GitHub

1. Créez un compte gratuit sur https://github.com
2. Cliquez sur **New repository**, nommez-le `pssst`, puis **Create repository**.
3. Cliquez sur **uploading an existing file** et glissez-y **tout le contenu** du dossier
   `pssst-android` (dézippé), en gardant les sous-dossiers (`app`, `.github`…).
   Astuce : sur ordinateur, glissez les dossiers directement depuis l'explorateur.
4. Cliquez sur **Commit changes**.
5. Ouvrez l'onglet **Actions** : la compilation « Construire l'APK Pssst » démarre (≈ 5 à 8 min).
6. Quand elle est verte ✅, cliquez dessus, puis en bas sur **pssst-apk** pour télécharger un zip
   contenant `app-debug.apk`.
7. Envoyez `app-debug.apk` sur vos téléphones (WhatsApp, câble, Drive…) et installez-le
   (autorisez « Installer des applis inconnues »).

> Le dossier `.github` est caché sur certains ordinateurs : vérifiez qu'il est bien envoyé,
> sinon la compilation ne démarre pas.

## 2. Ou avec Android Studio

1. Installez Android Studio (gratuit).
2. **File → Open** → choisissez le dossier `pssst-android`.
3. Attendez la synchronisation Gradle, puis **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`.

## 3. Utilisation avec vos amis

1. Chaque ami installe l'APK et ouvre Pssst.
2. Créez votre profil : photo, prénom, bio (visibles par tous autour), numéro et réseaux
   (partagés **uniquement** avec les amis acceptés ; laissez vide pour ne pas partager).
3. Acceptez les autorisations (Bluetooth, appareils à proximité, localisation) et **activez le
   Bluetooth et la localisation** du téléphone.
4. Onglet **Autour** : les amis proches apparaissent avec leur photo. Touchez **Pssst**.
5. L'autre personne touche **Accepter** → vous voyez son profil complet dans **Amis**
   (numéro, boutons Appeler / WhatsApp, liens vers ses réseaux).
6. Onglet **Messages** : discussions privées et **+ Groupe** pour créer un groupe avec vos amis.

## Ce qu'il faut savoir

- L'application doit être **ouverte** (au premier plan) pour être visible et recevoir des messages.
- Portée : environ 10 à 100 m selon les téléphones et les obstacles. La distance exacte n'est pas
  affichée (Nearby ne la fournit pas).
- Les messages vers un ami hors de portée sont **relayés** par les autres téléphones Pssst proches
  (3 relais maximum), puis renvoyés directement dès que l'ami revient à portée.
- La liaison entre deux téléphones est chiffrée par Nearby, mais un téléphone relais traite le
  message : ce n'est pas encore du chiffrement de bout en bout.
- Nécessite les **services Google Play** (absents sur les Huawei récents).
- Android 8.0 minimum. Les données restent sur le téléphone (aucun serveur).
